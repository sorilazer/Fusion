package model;

import java.io.Serializable;

public class Score implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3484710925042948564L;
	
	
	private int scorePoint;


	public int getScorePoint() {
		return scorePoint;
	}


	public void setScorePoint(int scorePoint) {
		this.scorePoint = scorePoint;
	}

}
