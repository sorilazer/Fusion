package model;

import java.io.Serializable;

public class PlayerTenis implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5329235436818520497L;
	
	private String name;
	private String firstName;
	private Score score;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Score getScore() {
		return score;
	}
	public void setScore(Score score) {
		this.score = score;
	}
	
	

}
