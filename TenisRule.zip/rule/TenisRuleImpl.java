package rule;

import model.PlayerTenis;

/**
 * Class of implementation tenis rules
 * @author Laser
 *
 */
public class TenisRuleImpl implements TenisRule{

	@Override
	public void scoreRule(PlayerTenis player1, PlayerTenis opposing) {

		try{
			
			int diff = player1.getScore().getScorePoint() - opposing.getScore().getScorePoint();

			if(player1.getScore().getScorePoint() >= 3 && opposing.getScore().getScorePoint() >=3){

				if(diff == 1 ){
					//"advantage� for the player1
					//TODO: implements 
				}else if(diff == -1){
					//"advantage� for the opposing
					//TODO: implements 
				}
				else if(diff == 0){
					//The score is �deuce�
					//TODO: implements 
				}
			}

			else if(diff == 2 && player1.getScore().getScorePoint() > opposing.getScore().getScorePoint() && player1.getScore().getScorePoint() >=4){
				//Player1 Wins
				//TODO: implements 
			} else if(diff == -2 && player1.getScore().getScorePoint() < opposing.getScore().getScorePoint() && opposing.getScore().getScorePoint() >=4){
				//Player opposing;
				//TODO: implements 
			}
		}


		catch (Exception e) {
			// TODO: handle exception
			//TODO log4j Implementaion to log error
		}

	}
}
