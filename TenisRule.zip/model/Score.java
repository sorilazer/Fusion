package model;

import java.io.Serializable;

/**
 * Class model of score
 * @author Lazer
 *
 */
public class Score implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3484710925042948564L;
	
	
	private int scorePoint;


	/**
	 * 
	 * @return
	 */
	public int getScorePoint() {
		return scorePoint;
	}

	/**
	 * 
	 * @param scorePoint
	 */
	public void setScorePoint(int scorePoint) {
		this.scorePoint = scorePoint;
	}

}
