package model;

import java.io.Serializable;

/**
 * Class model player
 * @author Lazer
 *
 */
public class PlayerTenis implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5329235436818520497L;
	
	private String name;
	
	private String firstName;
	
	private Score score;
	
	
	/**
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * 
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * 
	 * @return
	 */
	public Score getScore() {
		return score;
	}
	
	/**
	 * 
	 * @param score
	 */
	public void setScore(Score score) {
		this.score = score;
	}
	
	

}
